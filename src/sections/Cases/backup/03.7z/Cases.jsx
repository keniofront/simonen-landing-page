// Importa os dados dos projetos de um arquivo separado
import { projects } from '../../data/data.js';

// Importa o hook useState do React para gerenciar estados (como qual projeto está selecionado)
import { useState } from 'react';

// Importa o componente Modal, que será usado para mostrar os detalhes do projeto selecionado
import Modal from './Modal.jsx';

// Importa os estilos CSS específicos desse componente
import styles from './Cases.module.css';

// Componente interno CaseCard - representa cada "cartão" de projeto
function CaseCard({ project, onClick }) {
	return (
		// Quando o usuário clicar no card, chama a função onClick passando o projeto clicado
		<div className={styles.card} onClick={() => onClick(project)}>
			{/* Imagem do projeto (thumb = miniatura), com carregamento otimizado */}
			<img src={project.thumb} alt={project.name} loading="lazy" />

			{/* Sobreposição visível ao passar o mouse, mostrando o nome do projeto */}
			<div className={styles.overlay}>
				<span>{project.name}</span>
			</div>
		</div>
	);
}

// Componente interno CasesGrid - organiza todos os cards em uma grade
function CasesGrid({ projects, onSelect }) {
	return (
		<div className={styles.grid}>
			{/* Para cada projeto no array, renderiza um CaseCard */}
			{projects.map((p) => (
				<CaseCard key={p.id} project={p} onClick={onSelect} />
			))}
		</div>
	);
}

// Componente principal Cases
export default function Cases() {
	// Cria um estado chamado selected para guardar o projeto que o usuário clicou (inicialmente null)
	const [selected, setSelected] = useState(null);

	return (
		<section className={`section ${styles.section}`}>
			<div className={`container ${styles.container}`}>
				{/* Renderiza a grade de projetos, passando a função setSelected como manipulador de clique */}
				<CasesGrid projects={projects} onSelect={setSelected} />

				{/* Renderiza o Modal se houver um projeto selecionado (selected !== null) */}
				<Modal project={selected} onClose={() => setSelected(null)} />
			</div>
		</section>
	);
}
