import { useState, useEffect } from 'react';
import styles from './Modal.module.css';

// Componente Carousel com botões sobrepostos e autoplay
function Carousel({ images }) {
	const [index, setIndex] = useState(0);

	const next = () => setIndex((prev) => (prev + 1) % images.length);
	const prev = () => setIndex((prev) => (prev - 1 + images.length) % images.length);

	// Troca automática das imagens a cada 4 segundos
	useEffect(() => {
		const interval = setInterval(next, 4000);
		return () => clearInterval(interval);
	}, [images.length]);

	return (
		<div className={styles.carousel}>
			{/* Imagem de fundo do carrossel */}
			<img
				src={images[index]}
				alt={`Slide ${index + 1}`}
				loading='lazy'
				className={styles.image}
			/>

			{/* Botões sobrepostos à imagem */}
			<button className={`${styles.nav} ${styles.left}`} onClick={prev}>‹</button>
			<button className={`${styles.nav} ${styles.right}`} onClick={next}>›</button>
		</div>
	);
}

// Componente principal Modal
export default function Modal({ project, onClose }) {
	if (!project) return null;

	return (
		<div className={styles.backdrop} onClick={onClose}>
			<div className={styles.modal} onClick={(e) => e.stopPropagation()}>
				<button className={styles.close} onClick={onClose}>×</button>
				<Carousel images={project.images} />
				<div className={styles.content}>
					<h2>{project.name}</h2>
					<p><strong>O que foi feito:</strong> {project.description}</p>
					<p><strong>Como foi feito:</strong> {project.details}</p>
				</div>
			</div>
		</div>
	);
}
