// Importa useState para o controle do índice atual no carrossel
import { useState } from 'react';

// Importa os estilos CSS do modal e do carrossel
import styles from './Modal.module.css';

// Componente interno Carousel - mostra imagens do projeto uma por vez com botões de navegação
function Carousel({ images }) {
	const [index, setIndex] = useState(0); // Começa com a primeira imagem (índice 0)

	// Avança para a próxima imagem, voltando ao início quando chega no final
	const next = () => setIndex((index + 1) % images.length);

	// Volta para a imagem anterior, indo para o final se estiver na primeira
	const prev = () => setIndex((index - 1 + images.length) % images.length);

	return (
		<div className={styles.carousel}>
			<button onClick={prev}>‹</button>

			{/* Mostra a imagem atual do carrossel */}
			<div>
				<img src={images[index]} alt={`Slide ${index + 1}`} loading="lazy" />
			</div>

			<button onClick={next}>›</button>
		</div>
	);
}

// Componente Modal - mostra os detalhes do projeto e o carrossel
export default function Modal({ project, onClose }) {
	// Se nenhum projeto estiver selecionado, o modal não é renderizado
	if (!project) return null;

	return (
		// Fundo escuro que cobre toda a tela. Clicar aqui fecha o modal
		<div className={styles.backdrop} onClick={onClose}>
			{/* Caixa do modal em si - impede que o clique dentro feche o modal (propagação bloqueada) */}
			<div className={styles.modal} onClick={(e) => e.stopPropagation()}>
				{/* Botão de fechar no canto superior */}
				<button className={styles.close} onClick={onClose}>
					×
				</button>

				{/* Componente de carrossel com imagens do projeto */}
				<Carousel images={project.images} />

				{/* Conteúdo textual do projeto: título, descrição, detalhes */}
				<div className={styles.content}>
					<h2>{project.name}</h2>
					<p>
						<strong>O que foi feito:</strong> {project.description}
					</p>
					<p>
						<strong>Como foi feito:</strong> {project.details}
					</p>
				</div>
			</div>
		</div>
	);
}
