import CasesGrid from './components/CasesGrid.jsx';
import Modal from './components/Modal.jsx';
import styles from './styles/Cases.module.css';
import { projects } from '../../data/data.js';
import { useState } from 'react';

export default function Cases() {
	const [selected, setSelected] = useState(null); // Estado que guarda o projeto selecionado (para o modal)

	return (
		<section className={`section ${styles.section}`}>
			<div className={`container ${styles.container}`}>
				<div className={styles.text}>
					<div className={`section-tag`}>
						<h3>Nossa Equipe</h3>
						<hr />
					</div>
					<h1>Lorem ipsum dolor, sit amet consectetur adipisicing elit.</h1>
					<p>
						Lorem ipsum dolor sit amet consectetur, adipisicing elit. Distinctio, officia!Lorem ipsum dolor sit amet consectetur, adipisicing elit. Distinctio,
						officia!
					</p>
				</div>

				{/* Exibe a grade de projetos e passa a função setSelected como prop */}
				<CasesGrid projects={projects} onSelect={setSelected} />

				{/* Exibe o modal apenas se um projeto estiver selecionado */}
				<Modal project={selected} onClose={() => setSelected(null)} />
			</div>
		</section>
	);
}
