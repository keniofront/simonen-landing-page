import CaseCard from './CaseCard';
import styles from '../styles/CasesGrid.module.css';

// Exibe uma grade de cards de projetos. Cada card, quando clicado, chama onSelect passando o projeto correspondente.

export default function CasesGrid({ projects, onSelect }) {
  return (
    <div className={styles.grid}>
      {projects.map(p => (
        <CaseCard key={p.id} project={p} onClick={onSelect} />
      ))}
    </div>
  );
}
