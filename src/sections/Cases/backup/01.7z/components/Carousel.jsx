import { useState } from 'react';
import styles from '../styles/Carousel.module.css';

export default function Carousel({ images }) {
	const [index, setIndex] = useState(0); // Índice da imagem atual

	// Avança e Volta para a próxima imagem, com rotação circular
	const next = () => setIndex((index + 1) % images.length);
	const prev = () => setIndex((index - 1 + images.length) % images.length);

	return (
		<div className={styles.carousel}>
			<button onClick={prev}>‹</button>
			<div>
				<img src={images[index]} alt={`Slide ${index + 1}`} loading="lazy" />
			</div>
			<button onClick={next}>›</button>
		</div>
	);
}
