import styles from '../styles/CaseCard.module.css';

// Representa visualmente um projeto individual. Ao clicar, envia o projeto para a função onClick, que no Cases é o setSelected.

export default function CaseCard({ project, onClick }) {
  return (
    <div className={styles.card} onClick={() => onClick(project)}>
      <img src={project.thumb} alt={project.name} loading="lazy" />
      <div className={styles.overlay}>
        <span>{project.name}</span>
      </div>
    </div>
  );
}
