import styles from '../styles/Modal.module.css';
import Carousel from './Carousel';

export default function Modal({ project, onClose }) {
	if (!project) return null; // Não renderiza nada se nenhum projeto estiver selecionado

	return (
		<div className={styles.backdrop} onClick={onClose}>
			{/* Previne que o clique dentro do modal feche o modal (evento de propagação) */}

			<div className={styles.modal} onClick={(e) => e.stopPropagation()}>
				<button className={styles.close} onClick={onClose}>
					×
				</button>

				{/* Carrossel de imagens do projeto */}
				<Carousel images={project.images} />

				{/* Informações do projeto */}
				<div className={styles.content}>
					<h2>{project.name}</h2>
					<p>
						<strong>O que foi feito:</strong> {project.description}
					</p>
					<p>
						<strong>Como foi feito:</strong> {project.details}
					</p>
				</div>
			</div>
		</div>
	);
}
